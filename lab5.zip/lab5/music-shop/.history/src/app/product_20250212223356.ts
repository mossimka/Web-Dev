export interface Product {
    id: string;
    name: string;
    price: number;
    photo: string;
    subPhotos: string[];
    type: string;
    description: string;
    availableUnits: number;
    country: string;
    link: string;
    telegram: string;
    whatsapp: string;
    rating: number;
}
